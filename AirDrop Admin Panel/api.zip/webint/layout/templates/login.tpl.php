<div id="login">
	<form action="index.php" method="POST">
		<div id="login_01">
			<label id="login_01_01" for="login_01_02"><?php echo $this->content; ?></label>
			<input id="login_01_02" type="password" value="" name="password" />
			<label id="login_01_03" for="login_01_04" class="button">Enter<input id="login_01_04" type="submit" value="Enter" /></label>
		</div>
	</form>
</div>
