<?php if (!isset($root) && $root !== $_SERVER['DOCUMENT_ROOT']) die('You can not access this file directly!');
$config['root'] = '';
$config['locked'] = 'false';
$config['password'] = '';
?>
